import React from 'react';

function Footer() {
  return (
    <>
      <footer className='text-center'>Copyright @ thefarismd.</footer>
    </>
  );
}

export default Footer;
